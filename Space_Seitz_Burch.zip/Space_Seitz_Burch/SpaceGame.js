///////////////////////////////////////////////////////////////////////////////////////////////
//Editors: Brendan Burch & Anothny Seitz
///////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////
//Purpose: Use javascript to create functionality for space game.
//////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
//Brendan Burch: Commented lines 20-158
// ::resized sprite images & implemented spacebackground
//
//Anthony Seitz: Commented lines 158-221
//  ::selected sprite images for spaceship, swapped original images of ski out
//  :: fixed background color of image to blend into background
//
///////////////////////////////////////////////////////////////////////////////////////////


// canvas globals and game globals
var canvas,
ctx,
left = false,
right = false,
faster = false,
step = 0,
obst = [],
locX = 320,
locY = 100,
animationId = 0,
frames = 0,
running = true;

// image variables
var shipDown,
shipLeft,
shipRight,
boom,
meteor,
tree;

// after DOM is built
window.onload = function () {

//assigns "can" ID from html to canvas
canvas = document.getElementById("can");
//sets the  drawing for the  canvas to 2D
ctx = canvas.getContext("2d");


// background image-Brendan
spaceBG = new Image(); spaceBG.src="imgs/space-background.png";
//down facing ship-Brendan:resized :: Anthony: original image
shipDown = new Image(); shipDown.src = "imgs/spaceship_boi.png";
//ship image angled to the left-Brendan: resized :: Anthony: original image
shipLeft = new Image(); shipLeft.src = "imgs/spaceship_left.png";
//ship image andgled to the right- Brendan: resized :: Anthony: original image
shipRight = new Image(); shipRight.src = "imgs/spaceship_right.png";
//explosion image- Brendan: resized-swapped orig explosion image :: Anthony: edited background
boom = new Image(); boom.src = "imgs/boom.png";
//meteor image- Brendan: orignal image-resized :: Anthony: edited background
meteor = new Image(); meteor.src = "imgs/meteor.png";

tree = new Image(); tree.src = "imgs/tree.png";


//event listener inside the window for when a key is pressed down, calls anonymous fucntion to find keycode
window.addEventListener("keydown", (function (e) {
      
      // if left arrow key is being pressed
      if (e.keyCode == 37) { 
            //left boolean value becomes true
            left = true; 
      }

      //if right arrow key is being pressed
      else if (e.keyCode == 39) {
            //right boolean value becomes true
            right = true;
      }

      //if down arrow key is being pressed
      else if (e.keyCode == 40) {
            //faster boolean becomes true
            faster = true;
      }

      //if up arrowkey is pressed
      else if (e.keyCode == 38) {
            //running boolean becomes false
            //stops running program
            running = false;
      }
}));

//event listener inside the window for when a key is released, calls anonymous function to find keycode
window.addEventListener("keyup", (function (e) {
      
      //if left arrow is released
      if (e.keyCode == 37) {
            //direction of ship returns to straight
            left = false;
      }
      
      //if right arrow is released
      else if (e.keyCode == 39) {
            //direction of the ship returns to straight
            right = false;
      }

      //if down arrow is released
      else if (e.keyCode == 40) {
            //speed of ship returns to normal
            faster = false;
      }
      
      //if spacebar is pressed
      else if (e.keyCode == 32) {
      
            //when program is not running
            if (!running){
            //not moving
            step = 0;
            //create new array of obstacles
            obst = [];

            //reset location x,y coordinates to specific points on canvas
            locX = 320;
            locY = 100;

            //value of running is reassigned to true boolean
            running = true;
            //calls main program function to start game over again//
            runSpace();
            }
      }
}));

      // run the main program loop
      runSpace();
      }; //!

// constructor

//function to create random objects
function Obstacle() {

var num = Math.floor(Math.random() * 5);

      if (num === 0){
            this.type = meteor;
      }
      
      else{
            this.type = tree;
      }

      this.x = Math.floor(Math.random() * 1281);
      this.y = 640;
      } // ! 


//
function out(id, output) {
      document.getElementById(id).innerHTML = output;
} //!


// main function: runs ??? when?? how??
function runSpace() {

// 
if (left == true) {

      if (locX > -320){
            locX -= 2;
      }
}

if (right == true) {

      if (locX < 640 + 320){
            locX += 2;
      }
}

//creates the  boarder boundaries within the canvas
ctx.clearRect(0, 0, canvas.width, canvas.height);
//add space background to canvas
ctx.drawImage(spaceBG,0,0,canvas.width, canvas.height);
//draws the border as white to compensate background color
ctx.fillStyle = "rgb(255,255,255)";
//location of the boarder on the left of the canvas
ctx.fillRect(-10 - locX, 0, 10, canvas.height);
//location of the boarder on the right of the canvas
ctx.fillRect(640 * 2 + 20 - locX, 0, 10, canvas.height);

// 
var n = 10; // smaller number means ??
step = (step + 1) % n; // %n means ??

if (step == 0){
      obst.push(new Obstacle()); //??!!!
}

// 
for (var i = 0; i < obst.length; i++) {
      var o = obst[i];
      o.y -= 5;

if (faster == true){
      o.y -= 5;
}
ctx.drawImage(o.type, o.x - locX, o.y);

// 
if (o.y < -30) {
      obst.splice(i, 1);
      i--;
}

// 
var tX = o.x - locX + 5;
var tY = o.y + 5;
var d = Math.sqrt((tX - 320 + 3) * (tX - 320 + 3) + (tY - 100 + 5) * (tY - 100 + 5));


if (d < 20) {
ctx.drawImage(boom, 320, locY);
running = false;
               
if (animationId != 0) {
      cancelAnimationFrame(animationId);
      animationId = 0;
}
      return;
      }
}

// 
if (running == true) {

      if (left == true){
            ctx.drawImage(shipLeft, 320, locY);
      }
            
      else if (right == true){
            ctx.drawImage(shipRight, 320, locY);
      }

      else{
            ctx.drawImage(shipDown, 320, locY);
      }

//
out("outToScreen", "Spacebar Restarts! &nbsp; &nbsp;   LocX is currently: " + locX);

// !!!! this is a big deal
animationId = requestAnimationFrame(runSpace); // goal 60 frames/sec
      }
}